var MONEY=.01;
var Y=.01;
var MONEY2=0;

// function DoubleMyMoney(X){
//     for(var i=0;i<X;i++)
//     {
//         MONEY=MONEY*2;
//
//     }
// }
// DoubleMyMoney(30);
// console.log(MONEY);

var COUNT=0;
function DaysToRetirement(MONEY2){
    for(var J=0.01;J<MONEY2;J=J*2)
    {
        COUNT=COUNT+1;
    }
}
DaysToRetirement(Infinity);
console.log(COUNT);
